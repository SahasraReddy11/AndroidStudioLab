
package com.example.userlogin;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private TextView welcomeTextView;
    private Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        welcomeTextView = findViewById(R.id.welcomeTextView);
        logoutButton = findViewById(R.id.logoutButton);

        // Retrieve the email from the intent
        String email = getIntent().getStringExtra("email");

        // Check if the user has logged in before
        SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);
        boolean isFirstLogin = sharedPreferences.getBoolean(email + "_isFirstLogin", true); // Unique flag for each user

        // Set the welcome message based on first-time or returning user
        if (isFirstLogin) {
            welcomeTextView.setText("Welcome " + email);
            // Set the flag to false after the first login
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(email + "_isFirstLogin", false); // Unique for each email
            editor.apply();
        } else {
            welcomeTextView.setText("Welcome back " + email);
        }

        // Logout button functionality
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to LoginActivity without changing the login state
                Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Close this activity
            }
});
}
}